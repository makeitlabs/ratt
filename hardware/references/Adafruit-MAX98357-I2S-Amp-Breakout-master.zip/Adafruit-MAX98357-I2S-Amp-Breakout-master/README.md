# Adafruit-MAX98357-I2S-Amp-Breakout
PCB files for the Adafruit MAX98357 I2S Amp Breakout

These are the Eagle CAD files for the Adafruit MAX98357 I2S Amp Breakout:

   * https://www.adafruit.com/product/3006

Adafruit invests time and resources providing this open source design, please support Adafruit and open-source hardware by purchasing products from Adafruit!

Designed by Limor Fried/Ladyada for Adafruit Industries.
Creative Commons Attribution/Share-Alike, all text above must be included in any redistribution